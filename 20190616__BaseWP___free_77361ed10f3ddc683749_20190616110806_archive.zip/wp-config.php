<?php


/**

 * The base configuration for WordPress

 *

 * The wp-config.php creation script uses this file during the

 * installation. You don't have to use the web site, you can

 * copy this file to "wp-config.php" and fill in the values.

 *

 * This file contains the following configurations:

 *

 * * MySQL settings

 * * Secret keys

 * * Database table prefix

 * * ABSPATH

 *

 * @link https://codex.wordpress.org/Editing_wp-config.php

 *

 * @package WordPress

 */


// ** MySQL settings - You can get this info from your web host ** //

/** The name of the database for WordPress */

define( 'DB_NAME', '' );


/** MySQL database username */

define( 'DB_USER', '' );


/** MySQL database password */

define( 'DB_PASSWORD', '' );


/** MySQL hostname */

define( 'DB_HOST', '' );


/** Database Charset to use in creating database tables. */

define( 'DB_CHARSET', 'utf8mb4' );


/** The Database Collate type. Don't change this if in doubt. */

define( 'DB_COLLATE', '' );


/**#@+

 * Authentication Unique Keys and Salts.

 *

 * Change these to different unique phrases!

 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}

 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.

 *

 * @since 2.6.0

 */

define( 'AUTH_KEY',         'aTguFj+e`{w7mq0B+lo}=C%aVW|K3Wf`m2.|dK01}D*5cUCdUkQ?z*?yy-9Y_8_f' );

define( 'SECURE_AUTH_KEY',  'ZzP.5M%$J:9O|ZMDrl>:vh/S_w)FCh:uLD=:7MaSy%Kc:ed_Xkm5c5*QQLw)Qq4E' );

define( 'LOGGED_IN_KEY',    '^9zj(@l&G}@oCNkx@2_,-]K!T(?pf>E1GZx{sUYen%KJ%@Y.`g_~WE:=EXfft V&' );

define( 'NONCE_KEY',        'i(ocPQ-tGDNw3Q7wRw|Y&6Nv<t$~L/VY]11lr nd# qq5Q,]-4aoX f8k_:X?-aJ' );

define( 'AUTH_SALT',        'PH2.Mj2Ffo8bDj]{_8/>HB.8-Tx,M?h(R(wiCv~D:A6,KgVVQ^pwQV%$R0MHidJw' );

define( 'SECURE_AUTH_SALT', '=QINaxf3raQ_Q?[xFZDJxXig3:x=0pcq]wHy5|PIbw **A|]9V=2*^,[p*6]QenH' );

define( 'LOGGED_IN_SALT',   'NK,fFS% wH?&Hm!gg4;5W<7l?/QV>N8vzc?dbyz0$0#xw]|6VPZo] tpf0)P4BWi' );

define( 'NONCE_SALT',       ',K9`aq`G3J;/[DwJgr6g(p 2aY=1N+XP)t+#m $TWpo8(jNS.jD*426`)P^{lJ_n' );


/**#@-*/


/**

 * WordPress Database Table prefix.

 *

 * You can have multiple installations in one database if you give each

 * a unique prefix. Only numbers, letters, and underscores please!

 */

$table_prefix = 'BA_';


/**

 * For developers: WordPress debugging mode.

 *

 * Change this to true to enable the display of notices during development.

 * It is strongly recommended that plugin and theme developers use WP_DEBUG

 * in their development environments.

 *

 * For information on other constants that can be used for debugging,

 * visit the Codex.

 *

 * @link https://codex.wordpress.org/Debugging_in_WordPress

 */

define( 'WP_DEBUG', false );


/* That's all, stop editing! Happy publishing. */


/** Absolute path to the WordPress directory. */

if ( ! defined( 'ABSPATH' ) ) {

	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

}


/** Sets up WordPress vars and included files. */

require_once( ABSPATH . 'wp-settings.php' );

